﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace DBS
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private SqlConnection conn;
        

        public MainWindow()
        {
            InitializeComponent();

            conn = new SqlConnection(@"Data Source=DESKTOP-VRPRT3F\SQLEXPRESS;Initial Catalog=master;Integrated Security=True");

            using (conn)
            {
                conn.Open();
                string sql = "SELECT ID, Meno, Kontaktna_adresa AS Adresa FROM T_HEREC";
                SqlCommand com = new SqlCommand(sql, conn);

                    
                using (SqlDataAdapter adapter = new SqlDataAdapter(com))
                {
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    herec.ItemsSource = dt.DefaultView;
                }

              /*  using (SqlCommand command = new SqlCommand("SELECT ID FROM T_HEREC", conn))
                {
                    int result = (int)command.ExecuteScalar();
                    vypis.Text = Convert.ToString(result);

                }*/

            }

        }

        
/*
        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

            conn = new SqlConnection(@"Data Source=DESKTOP-VRPRT3F\SQLEXPRESS;Initial Catalog=master;Integrated Security=True");

            using (conn)
            {
                using (SqlCommand command = new SqlCommand(
                             "SELECT Meno FROM T_HEREC WHERE ID=50", conn))
                {
                    conn.Open();
                    string result = (string)command.ExecuteScalar();
                    vypis.Text =result;
                    
                }
            }
        }
        */
        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            int currentRowIndex = herec.Items.IndexOf(herec.CurrentItem);
            int currentRowIndex2 = currentRowIndex + 1;
            vypis.Text = Convert.ToString(currentRowIndex);

            conn = new SqlConnection(@"Data Source=DESKTOP-VRPRT3F\SQLEXPRESS;Initial Catalog=master;Integrated Security=True");

            using (conn)
            {
                using (SqlCommand command = new SqlCommand(
                    "Select top "+@currentRowIndex2+" ID From T_HEREC EXCEPT Select top "+@currentRowIndex+" ID From T_HEREC", conn))
                    
                {
                    conn.Open();
                    int result = (int)command.ExecuteScalar();
                    vypis2.Text = Convert.ToString(result);
                    
                   string sql = @"DELETE FROM T_HEREC WHERE ID =" +@result;
                   using (SqlCommand cmd = new SqlCommand(sql, conn))
                        {
                            cmd.ExecuteNonQuery();
                            MessageBox.Show(string.Format("Data su vymazane."));
                            
                        }

                    string sql2 = @"DELETE FROM T_DIVADELNY_HEREC WHERE HEREC_ID =" + @result;
                    using (SqlCommand cmd = new SqlCommand(sql2, conn))
                    {
                        cmd.ExecuteNonQuery();
                        
                    }

                    string sql3 = @"DELETE FROM T_FILMOVY_HEREC WHERE HEREC_ID =" + @result;
                    using (SqlCommand cmd = new SqlCommand(sql3, conn))
                    {
                        cmd.ExecuteNonQuery();

                    }

                    string sql4 = @"DELETE FROM T_SERIALOVY_HEREC WHERE HEREC_ID =" + @result;
                    using (SqlCommand cmd = new SqlCommand(sql4, conn))
                    {
                        cmd.ExecuteNonQuery();

                    }

                    string sql5 = @"DELETE FROM T_HEREC_V_PREDSTAVENI WHERE HEREC_ID =" + @result;
                    using (SqlCommand cmd = new SqlCommand(sql5, conn))
                    {
                        cmd.ExecuteNonQuery();

                    }

                    string sql6 = @"DELETE FROM T_OCENENIE WHERE HEREC_ID =" + @result;
                    using (SqlCommand cmd = new SqlCommand(sql6, conn))
                    {
                        cmd.ExecuteNonQuery();

                    }

                }
            }

        }

        private void InfoButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Novy_herec_Click(object sender, RoutedEventArgs e)
        {

        }

        private void textBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void textBox_TextChanged_1(object sender, TextChangedEventArgs e)
        {

        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            conn = new SqlConnection(@"Data Source=DESKTOP-VRPRT3F\SQLEXPRESS;Initial Catalog=master;Integrated Security=True");

            using (conn)
            {
                conn.Open();
                string sql = "SELECT ID, Meno, Kontaktna_adresa AS Adresa FROM T_HEREC";
                SqlCommand com = new SqlCommand(sql, conn);


                using (SqlDataAdapter adapter = new SqlDataAdapter(com))
                {
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    herec.ItemsSource = dt.DefaultView;
                }
            }
        }
    }
}
